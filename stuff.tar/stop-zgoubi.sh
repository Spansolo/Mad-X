#!/bin/bash

echo "stopping zgoubi container..."
docker stop zgoubi
echo "stopping zgoubi container... done"
